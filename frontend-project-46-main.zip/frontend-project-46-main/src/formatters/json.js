const formatJson = diff => JSON.stringify(diff, null, 2)

module.exports = formatJson
